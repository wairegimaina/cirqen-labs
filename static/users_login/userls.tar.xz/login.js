/**
 * Password Toggle Functionality
 * Adds show/hide password toggle button to password input fields
 *
 * @version 1.0.0
 * @author Cirqen Development Team
 */

document.addEventListener('DOMContentLoaded', function () {
  // Find the password input field
  const passwordField = document.querySelector('input[type="password"]');

  if (!passwordField) {
    console.warn('Password field not found');
    return;
  }

  // Get the parent input group
  const inputGroup = passwordField.closest('.input-group');

  if (!inputGroup) {
    console.warn('Input group not found for password field');
    return;
  }

  // Add password-field class to the input group
  inputGroup.classList.add('password-field');

  // Get the input container (direct parent)
  const inputContainer = passwordField.parentElement;

  // Check if toggle button already exists (prevent duplicates)
  if (inputContainer.querySelector('.password-toggle')) {
    console.log('Password toggle already initialized');
    return;
  }

  // Create the toggle button
  const toggleButton = document.createElement('button');
  toggleButton.type = 'button';
  toggleButton.className = 'password-toggle';
  toggleButton.setAttribute('aria-label', 'Toggle password visibility');
  toggleButton.setAttribute('data-tooltip', 'Show password');
  toggleButton.innerHTML = '<i class="fas fa-eye-slash"></i>';

  // Append button to input container
  inputContainer.appendChild(toggleButton);

  // Add click event listener
  toggleButton.addEventListener('click', function (e) {
    // Prevent form submission and event bubbling
    e.preventDefault();
    e.stopPropagation();

    // Check current password field type
    const isPassword = passwordField.type === 'password';

    if (isPassword) {
      // Show password
      passwordField.type = 'text';
      this.innerHTML = '<i class="fas fa-eye"></i>';
      this.setAttribute('data-tooltip', 'Hide password');
      this.setAttribute('aria-label', 'Hide password');
      this.classList.add('active');
    } else {
      // Hide password
      passwordField.type = 'password';
      this.innerHTML = '<i class="fas fa-eye-slash"></i>';
      this.setAttribute('data-tooltip', 'Show password');
      this.setAttribute('aria-label', 'Show password');
      this.classList.remove('active');
    }
  });

  console.log('Password toggle initialized successfully');
});
