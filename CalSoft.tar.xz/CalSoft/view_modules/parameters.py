import logging
from decimal import Decimal
from django.utils import timezone
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_http_methods, require_GET
from django.shortcuts import render, get_object_or_404, redirect
from django.http import JsonResponse
from django.contrib import messages
from django.db import transaction
from django.core.paginator import Paginator

from CalSoft.models import Standard, Parameter, CalibrationAuditLog
from CalSoft.forms import (
    CalibrationScheduleForm, StandardForm, ParameterForm, StandardParameterFormSet
)

def is_ajax(request):
    return (
        request.headers.get("X-Requested-With") == "XMLHttpRequest"
        or "application/json" in request.headers.get("Accept", "")
    )

logger = logging.getLogger(__name__)


@login_required
def standards_list(request):
    try:
        standards = Standard.objects.all().order_by('name')
        paginator = Paginator(standards, 20)
        page_number = request.GET.get('page')
        page_obj = paginator.get_page(page_number)

        context = {
            'page_obj': page_obj,
            'total_standards': standards.count(),
            'show_sidebar': True,
        }
        return render(request, 'Calibration/standards_list.html', context)
    except Exception as e:
        logger.error(f"Error loading standards list: {str(e)}")
        messages.error(request, f"Error loading standards: {str(e)}")
        return redirect('calibration:calsoft_dashboard')


@login_required
def standard_create(request):
    if request.method == 'POST':
        form = StandardForm(request.POST)
        formset = StandardParameterFormSet(request.POST, prefix='parameters')
        if form.is_valid() and formset.is_valid():
            with transaction.atomic():
                standard = form.save(commit=False)
                standard.created_by = request.user
                standard.save()
                formset.instance = standard
                formset.save()
                messages.success(request, 'Standard created successfully.')
                return redirect('calibration:standard_create')
        else:
            messages.error(request, 'Please correct the errors below.')
    else:
        form = StandardForm()
        formset = StandardParameterFormSet(prefix='parameters')

    parameters = Parameter.objects.all()
    context = {
        'form': form,
        'formset': formset,
        'parameters': parameters,
        'show_sidebar': True,
    }
    return render(request, 'Calibrition/standard_form.html', context)


@login_required
def standard_edit(request, pk):
    standard = get_object_or_404(Standard, pk=pk)

    if request.method == 'POST':
        form = StandardForm(request.POST, instance=standard)
        formset = StandardParameterFormSet(request.POST, instance=standard, prefix='parameters')

        if form.is_valid() and formset.is_valid():
            with transaction.atomic():
                standard = form.save()
                formset.save()

                CalibrationAuditLog.objects.create(
                    user=request.user,
                    action='update_standard',
                    description=f"Updated standard: {standard.name}"
                )

                if is_ajax(request):
                    return JsonResponse({
                        'success': True,
                        'standard': {
                            'id': str(standard.pk),
                            'name': standard.name,
                            'model_number': standard.model_number,
                            'serial_number': standard.serial_number,
                            'manufacturer': standard.manufacturer,
                            'calibration_date': standard.calibration_date.strftime('%Y-%m-%d') if standard.calibration_date else None,
                            'calibration_due_date': standard.calibration_due_date.strftime('%Y-%m-%d') if standard.calibration_due_date else None
                        }
                    })

                messages.success(request, 'Standard updated successfully.')
                return redirect('calibration:StandardsParameters_lists')
        else:
            errors = {}
            if form.errors:
                errors['form'] = {field: [str(e) for e in errors] for field, errors in form.errors.items()}
            if formset.errors:
                errors['formset'] = []
                for idx, error_dict in enumerate(formset.errors):
                    if error_dict:
                        errors['formset'].append({
                            'index': idx,
                            'errors': {field: [str(e) for e in errors] for field, errors in error_dict.items()}
                        })

            if is_ajax(request):
                return JsonResponse({'success': False, 'errors': errors}, status=400)

            messages.error(request, 'Please correct the errors.')
    else:
        form = StandardForm(instance=standard)
        formset = StandardParameterFormSet(instance=standard, prefix='parameters')

    parameters = Parameter.objects.filter(active_status=True)
    context = {'form': form, 'formset': formset, 'parameters': parameters, 'standard': standard, 'show_sidebar': True}

    if is_ajax(request):
        return render(request, 'Calibrition/standard_form.html', context)

    return render(request, 'Calibrition/standard_form.html', context)


@login_required
def standard_delete(request, pk):
    if request.method == 'POST':
        try:
            standard = get_object_or_404(Standard, pk=pk)

            if hasattr(standard, 'pending_delete'):
                standard.pending_delete = True
                standard.updated_at = timezone.now()
                standard.save(update_fields=['pending_delete', 'updated_at'])
                return JsonResponse({
                    'success': True,
                    'message': 'Standard marked for deletion. It will be removed after syncing with HQ.'
                })
            else:
                standard.delete()
                return JsonResponse({'success': True})

        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)}, status=400)

    return JsonResponse({'success': False, 'error': 'Invalid request method.'}, status=405)


@login_required
def parameter_create(request):
    if request.method == 'POST':
        form = ParameterForm(request.POST)
        if form.is_valid():
            parameter = form.save(commit=False)
            parameter.created_by = request.user
            parameter.save()
            if is_ajax(request):
                return JsonResponse({
                    'success': True,
                    'parameter': {
                        'id': parameter.pk,
                        'name': parameter.name
                    }
                })
            return redirect('calibration:standard_create')
        else:
            if is_ajax(request):
                return JsonResponse({
                    'success': False,
                    'errors': form.errors.as_json()
                }, status=400)
            messages.error(request, 'Please correct the errors below.')
    else:
        form = ParameterForm()

    context = {'form': form, 'show_sidebar': True}
    return render(request, 'Calibrition/parameter_form.html', context)


@login_required
def parameter_edit(request, pk):
    parameter = get_object_or_404(Parameter, pk=pk)

    if request.method == 'POST':
        form = ParameterForm(request.POST, instance=parameter)
        if form.is_valid():
            parameter = form.save()
            if is_ajax(request):
                return JsonResponse({
                    'success': True,
                    'parameter': {
                        'id': parameter.pk,
                        'name': parameter.name,
                        'symbol': parameter.symbol,
                        'unit': parameter.unit
                    }
                })
            messages.success(request, 'Parameter updated successfully.')
            return redirect('calibration:calibration_lists')
        else:
            if is_ajax(request):
                return JsonResponse({
                    'success': False,
                    'errors': form.errors.as_json()
                }, status=400)
            messages.error(request, 'Please correct the errors below.')
    else:
        if is_ajax(request):
            return JsonResponse({
                'name': parameter.name,
                'symbol': parameter.symbol,
                'unit': parameter.unit
            })
        form = ParameterForm(instance=parameter)
        context = {'form': form, 'show_sidebar': True}
        return render(request, 'calibration/parameter_form.html', context)


@login_required
def parameter_delete(request, pk):
    if request.method == 'POST':
        try:
            parameter = get_object_or_404(Parameter, pk=pk)

            if hasattr(parameter, 'pending_delete'):
                parameter.pending_delete = True
                parameter.updated_at = timezone.now()
                parameter.save(update_fields=['pending_delete', 'updated_at'])
                return JsonResponse({
                    'success': True,
                    'message': 'Parameter marked for deletion. It will be removed after syncing with HQ.'
                })
            else:
                parameter.delete()
                return JsonResponse({'success': True})

        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)}, status=400)

    return JsonResponse({'success': False, 'error': 'Invalid request method.'}, status=405)


@login_required
def StandardsParameters_lists(request):
    standards = Standard.objects.all().order_by('name')
    parameters = Parameter.objects.all().order_by('name')
    context = {
        'standards': standards,
        'parameters': parameters,
        'show_sidebar': True,
    }
    return render(request, 'Calibrition/stand-parameters-list.html', context)